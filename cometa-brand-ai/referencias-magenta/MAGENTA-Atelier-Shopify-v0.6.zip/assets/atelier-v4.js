(()=>{'use strict';
const reduced=matchMedia('(prefers-reduced-motion:reduce)');
const activeObservers=new Map();
function initialize(scope=document){
const intro=scope.querySelector('[data-brand-intro]');if(intro){intro.addEventListener('animationend',e=>{if(e.animationName==='brand-exit')intro.remove();});if(reduced.matches||document.body.classList.contains('motion-off'))intro.remove();}
if(reduced.matches)scope.querySelectorAll('video[autoplay]').forEach(v=>v.pause());
if(document.body.classList.contains('reveal-enabled')&&!document.body.classList.contains('motion-off')&&!reduced.matches&&!window.Shopify?.designMode&&'IntersectionObserver'in window){
const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.remove('is-pending');observer.unobserve(entry.target);}});},{threshold:.05});
scope.querySelectorAll('.section-heading,.editorial-card,.look-content,.footer-column').forEach(el=>{if(el.getBoundingClientRect().top>innerHeight){el.classList.add('reveal-target','is-pending');observer.observe(el);}});activeObservers.set(scope,observer);
}
}
initialize();
document.addEventListener('shopify:section:load',e=>initialize(e.target));
document.addEventListener('shopify:section:unload',e=>{activeObservers.get(e.target)?.disconnect();activeObservers.delete(e.target);});
document.addEventListener('shopify:section:select',e=>e.target.querySelectorAll('.is-pending').forEach(el=>el.classList.remove('is-pending')));
document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;document.querySelector('[data-menu-toggle]')?.setAttribute('aria-expanded','false');document.getElementById('MainMenu')?.classList.remove('open');});
// Accessible tab navigation in collection sections.
document.addEventListener('keydown',e=>{const tab=e.target.closest('[data-collection-tab]');if(!tab||!['ArrowRight','ArrowLeft','Home','End'].includes(e.key))return;const tabs=[...tab.closest('[role=tablist]').querySelectorAll('[data-collection-tab]')];let i=tabs.indexOf(tab);i=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;e.preventDefault();tabs[i].click();tabs[i].focus();});
})();
