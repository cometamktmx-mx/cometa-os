(()=>{'use strict';
const i18n={...{"operation_error": "No pudimos completar la operación. Intenta nuevamente.", "unit_price": " por pieza", "decrease": "Reducir cantidad", "increase": "Aumentar cantidad", "remove": "Eliminar", "favorite_removed": "Prenda eliminada de favoritos.", "favorite_saved": "Prenda guardada en este navegador.", "favorite_error": "El navegador no permite guardar favoritos.", "product_load_error": "No pudimos cargar esta prenda.", "product_open": "Abre la ficha del producto para elegir tu prenda.", "variant_error": "No pudimos actualizar la variante.", "variant_retry": "Selecciona nuevamente tu talla y color.", "variant_unavailable": "Esta combinación no está disponible.", "adding": "Agregando…", "favorites_empty": "Guarda tus favoritos con el corazón de cada prenda.", "choose_size": "Elegir talla ＋", "favorites_unavailable": "Tus favoritos no están disponibles. Explora la colección para guardar nuevas prendas.", "search_prompt": "Escribe para explorar la tienda.", "searching": "Buscando…", "search_collection": "Colección · ", "search_found": "Encontramos ", "search_options": " opciones.", "search_empty": "Sin coincidencias. Prueba con otro nombre o usa Buscar para ver todos los resultados.", "search_error": "Usa Buscar para consultar todos los resultados."},...(window.Magenta?.strings||{})};

const panel=document.getElementById('SearchPanel');
if(!panel)return;
const field=panel.querySelector('[name=q]'),results=panel.querySelector('#SearchResults'),status=panel.querySelector('[data-search-status]');
let timer,controller,version=0;
const create=(tag,value)=>{const el=document.createElement(tag);el.textContent=value;return el;};
const safeURL=value=>{try{const u=new URL(value,location.origin);return u.origin===location.origin?u.href:null;}catch{return null;}};
async function search(query,requestVersion){
controller?.abort();controller=new AbortController();
results.replaceChildren();if(!query.trim()){status.textContent=i18n.search_prompt;return;}
status.textContent=i18n.searching;
try{
const params=new URLSearchParams({q:query,'resources[type]':'product,collection','resources[limit]':String(window.Magenta?.searchLimit||6)});
const response=await fetch((window.Magenta?.root||'/')+'search/suggest.json?'+params,{signal:controller.signal});
if(!response.ok)throw Error();const data=await response.json();if(version!==requestVersion)return;
const matches=data.resources?.results||{};
for(const product of matches.products||[]){const url=safeURL(product.url);if(!url)continue;const card=create('a','');card.className='search-result';card.href=url;const image=product.featured_image?.url||product.image;if(image){const img=document.createElement('img');img.src=image;img.alt=product.title;img.loading='lazy';card.append(img);}const info=create('div','');info.append(create('h3',product.title));const price=Number(product.price);if(Number.isFinite(price))info.append(create('p',new Intl.NumberFormat(document.documentElement.lang||'es-MX',{style:'currency',currency:window.Magenta?.currency||'MXN'}).format(price)));card.append(info);results.append(card);}
for(const collection of matches.collections||[]){const url=safeURL(collection.url);if(!url)continue;const link=create('a',i18n.search_collection+collection.title+' ↗');link.href=url;link.className='search-collection';results.append(link);}
status.textContent=results.childElementCount?i18n.search_found+results.childElementCount+i18n.search_options:i18n.search_empty;
}catch(error){if(error.name==='AbortError'||version!==requestVersion)return;status.textContent=i18n.search_error;}
}
field.addEventListener('input',()=>{clearTimeout(timer);const v=++version;controller?.abort();timer=setTimeout(()=>search(field.value,v),200);});
document.addEventListener('click',event=>{
const target=event.target;
if(target.closest('[data-open-search]')){event.preventDefault();panel.showModal();field.focus();}
if(target.closest('[data-close-search]'))panel.close();
const step=target.closest('[data-rail-step]');if(step){const rail=step.closest('section').querySelector('.product-grid:not([hidden])');rail?.scrollBy({left:rail.clientWidth*Number(step.dataset.railStep),behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'});}
if(!target.closest('.mega-group'))document.querySelectorAll('.mega-group[open]').forEach(group=>group.open=false);
});
document.addEventListener('keydown',event=>{if(event.key==='Escape')document.querySelectorAll('.mega-group[open]').forEach(group=>group.open=false);});
document.addEventListener('toggle',event=>{if(event.target.matches('.mega-group')&&event.target.open)document.querySelectorAll('.mega-group[open]').forEach(group=>{if(group!==event.target)group.open=false;});},true);
panel.addEventListener('click',event=>{if(event.target!==panel)return;const r=panel.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)panel.close();});
})();
