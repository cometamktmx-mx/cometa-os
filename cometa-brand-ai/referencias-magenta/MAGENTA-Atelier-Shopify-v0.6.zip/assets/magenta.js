(()=>{'use strict';
const i18n={...{"operation_error": "No pudimos completar la operación. Intenta nuevamente.", "unit_price": " por pieza", "decrease": "Reducir cantidad", "increase": "Aumentar cantidad", "remove": "Eliminar", "favorite_removed": "Prenda eliminada de favoritos.", "favorite_saved": "Prenda guardada en este navegador.", "favorite_error": "El navegador no permite guardar favoritos.", "product_load_error": "No pudimos cargar esta prenda.", "product_open": "Abre la ficha del producto para elegir tu prenda.", "variant_error": "No pudimos actualizar la variante.", "variant_retry": "Selecciona nuevamente tu talla y color.", "variant_unavailable": "Esta combinación no está disponible.", "adding": "Agregando…", "favorites_empty": "Guarda tus favoritos con el corazón de cada prenda.", "choose_size": "Elegir talla ＋", "favorites_unavailable": "Tus favoritos no están disponibles. Explora la colección para guardar nuevas prendas.", "search_prompt": "Escribe para explorar la tienda.", "searching": "Buscando…", "search_collection": "Colección · ", "search_found": "Encontramos ", "search_options": " opciones.", "search_empty": "Sin coincidencias. Prueba con otro nombre o usa Buscar para ver todos los resultados.", "search_error": "Usa Buscar para consultar todos los resultados."},...(window.Magenta?.strings||{})};

const cfg=window.Magenta||{root:'/',currency:'MXN'},drawer=document.getElementById('CartDrawer'),quick=document.getElementById('QuickBuy'),zoom=document.getElementById('PhotoZoom');
const money=n=>new Intl.NumberFormat(document.documentElement.lang||'es-MX',{style:'currency',currency:cfg.currency||'MXN'}).format(n/100);
const text=(tag,value)=>{const el=document.createElement(tag);el.textContent=value;return el;};
let cartBusy=false,cartVersion=0;const optionRequests=new WeakMap();
function feedback(value){const el=document.querySelector('.toast');el.textContent=value;el.classList.add('active');clearTimeout(feedback.timer);feedback.timer=setTimeout(()=>el.classList.remove('active'),3500);}
async function jsonFetch(url,options={}){const r=await fetch(url,options),data=await r.json();if(!r.ok)throw Error(typeof data.description==='string'?data.description:i18n.operation_error);return data;}
function renderCart(cart){const target=drawer.querySelector('[data-cart-content]');target.replaceChildren();document.querySelectorAll('[data-cart-count]').forEach(el=>el.textContent=cart.item_count);drawer.querySelector('[data-cart-total]').textContent=money(cart.total_price);drawer.querySelector('[data-checkout]').disabled=!cart.items.length;
if(!cart.items.length){const empty=text('div','');empty.className='drawer-empty';empty.append(text('h3',cfg.cartEmpty||'Tu próximo favorito está esperando.'));const link=text('a',(cfg.cartContinue||'Explorar colección')+' →');link.className='button';link.href=cfg.cartContinueLink||cfg.root+'collections/all';empty.append(link);target.append(empty);return;}
cart.items.forEach(item=>{const row=text('div','');row.className='drawer-item';if(item.image){const img=document.createElement('img');img.src=item.image;img.alt=item.product_title;row.append(img);}const info=text('div',''),heading=text('h3',''),link=text('a',item.product_title);link.href=item.url;heading.append(link);info.append(heading);if(item.variant_title)info.append(text('p',item.variant_title));info.append(text('p',money(item.final_price)+i18n.unit_price));const controls=text('div','');controls.className='drawer-item-controls';const qty=text('div','');qty.className='quantity';for(const delta of [-1,1]){const b=text('button',delta<0?'−':'＋');b.type='button';b.dataset.cartKey=item.key;b.dataset.cartQuantity=String(Math.max(0,item.quantity+delta));b.setAttribute('aria-label',delta<0?i18n.decrease:i18n.increase);qty.append(b);if(delta<0){const amount=text('span',String(item.quantity));amount.style.cssText='min-width:32px;text-align:center;font-size:12px';qty.append(amount);}}const total=text('span',money(item.final_line_price));total.className='drawer-line-total';controls.append(qty,total);info.append(controls);const remove=text('button',i18n.remove);remove.className='remove-line';remove.type='button';remove.dataset.cartKey=item.key;remove.dataset.cartQuantity='0';info.append(remove);(item.line_level_discount_allocations||[]).forEach(d=>info.append(text('p',d.discount_application.title)));row.append(info);target.append(row);});(cart.cart_level_discount_applications||[]).forEach(d=>target.append(text('p',d.title+' −'+money(d.total_allocated_amount))));}
async function loadCart(){const version=++cartVersion;drawer.querySelector('.drawer-error').textContent='';drawer.querySelector('[data-checkout]').disabled=true;try{const cart=await jsonFetch(cfg.root+'cart.js');if(version===cartVersion)renderCart(cart);}catch(e){if(version===cartVersion){drawer.querySelector('.drawer-error').textContent=e.message;drawer.querySelector('[data-checkout]').disabled=true;}}}
function openCart(){if(!drawer.open)drawer.showModal();return loadCart();}
async function changeCart(button){if(cartBusy)return;cartBusy=true;drawer.querySelectorAll('[data-cart-key]').forEach(b=>b.disabled=true);drawer.querySelector('[data-checkout]').disabled=true;try{++cartVersion;const cart=await jsonFetch(cfg.root+'cart/change.js',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({id:button.dataset.cartKey,quantity:Number(button.dataset.cartQuantity)})});renderCart(cart);drawer.querySelector('.drawer-error').textContent='';}catch(e){drawer.querySelector('.drawer-error').textContent=e.message;drawer.querySelector('[data-checkout]').disabled=true;}finally{cartBusy=false;drawer.querySelectorAll('[data-cart-key]').forEach(b=>b.disabled=false);}}
function favorites(){try{const v=JSON.parse(localStorage.getItem('magenta-favorites')||'[]');return Array.isArray(v)?v.filter(x=>typeof x==='string'):[];}catch{return[];}}
function syncFavorites(){const list=favorites();document.querySelectorAll('[data-favorite]').forEach(b=>{const yes=list.includes(b.dataset.favorite);b.setAttribute('aria-pressed',String(yes));b.textContent=yes?'♥':'♡';});}
function toggleFavorite(b){const list=favorites(),handle=b.dataset.favorite;try{localStorage.setItem('magenta-favorites',JSON.stringify(list.includes(handle)?list.filter(h=>h!==handle):[...list,handle]));syncFavorites();feedback(list.includes(handle)?i18n.favorite_removed:i18n.favorite_saved);}catch{feedback(i18n.favorite_error);}}
const parseHTML=html=>new DOMParser().parseFromString(html,'text/html');
async function quickBuy(button){button.disabled=true;try{const r=await fetch(button.dataset.quickBuy);if(!r.ok)throw Error(i18n.product_load_error);const root=parseHTML(await r.text()).querySelector('[data-product-root]');if(!root)throw Error(i18n.product_open);prefixQuickIds(root);quick.querySelector('[data-quick-content]').replaceChildren(root);quick.showModal();syncFavorites();}catch(e){feedback(e.message);}finally{button.disabled=false;}}
async function updateOptions(input){
  const root=input.closest('[data-product-root]');if(!root)return;
  optionRequests.get(root)?.abort();
  const controller=new AbortController();optionRequests.set(root,controller);
  const ids=root.dataset.optionValues?root.dataset.optionValues.split(','):[];
  [...root.querySelectorAll('[data-option-value]:checked')].forEach((radio,index)=>{const position=Number(radio.closest('[data-option-position]')?.dataset.optionPosition)||index+1;ids[position-1]=radio.value;});
  const url=new URL(root.dataset.productUrl,location.origin);
  url.searchParams.set('section_id',root.dataset.sectionId);url.searchParams.set('option_values',ids.join(','));
  const buttons=[...root.querySelectorAll('[data-add-button],[data-sticky-add]')];
  // Original state survives multiple rapid selections on this same rendered root.
  if(!root._optionButtonStates)root._optionButtonStates=buttons.map(b=>b.disabled);
  root.setAttribute('aria-busy','true');buttons.forEach(b=>b.disabled=true);
  root.querySelectorAll('.shopify-payment-button').forEach(el=>el.inert=true);
  const error=root.querySelector('.form-error');if(error)error.textContent='';
  try{
    const response=await fetch(url,{signal:controller.signal});
    if(!response.ok)throw Error(i18n.variant_error);
    const html=await response.text();
    if(controller.signal.aborted||optionRequests.get(root)!==controller||!root.isConnected)return;
    const replacement=parseHTML(html).querySelector('[data-product-root]');
    if(!replacement)throw Error(i18n.variant_retry);
    const quantity=replacement.querySelector('[name=quantity]');
    if(quantity){quantity.value=root.querySelector('[name=quantity]')?.value||'1';if(!quantity.checkValidity())quantity.value=quantity.min||'1';}
    const isQuick=!!root.closest('#QuickBuy');if(isQuick)prefixQuickIds(replacement);
    const active=document.activeElement;
    const focusedOption=active?.matches('[data-option-value]')&&root.contains(active)?active.value:null;
    const focusedQuantity=root.contains(active)&&active?.name==='quantity';
    const openBlocks=[...root.querySelectorAll('.product-accordion[open]')].map(el=>el.closest('[data-product-block]')?.dataset.productBlock);
    root._stickyObserver?.disconnect();root.replaceWith(replacement);initSticky(replacement);
    replacement.querySelectorAll('.product-accordion').forEach(el=>{if(openBlocks.includes(el.closest('[data-product-block]')?.dataset.productBlock))el.open=true;});
    replacement.dispatchEvent(new CustomEvent('magenta:variant:change',{bubbles:true,detail:{variantId:replacement.dataset.variantId||replacement.querySelector('[name=id]')?.value||null,root:replacement}}));
    if(!isQuick){
      const variant=replacement.dataset.variantId??replacement.querySelector('[name=id]')?.value,pageURL=new URL(location.href);
      pageURL.searchParams.delete('section_id');
      if(variant){pageURL.searchParams.set('variant',variant);pageURL.searchParams.delete('option_values');}
      else{pageURL.searchParams.delete('variant');pageURL.searchParams.set('option_values',ids.join(','));}
      history.replaceState({},'',pageURL);
    }
    if(focusedOption)[...replacement.querySelectorAll('[data-option-value]')].find(x=>x.value===focusedOption)?.focus({preventScroll:true});
    else if(focusedQuantity)quantity?.focus({preventScroll:true});
    syncFavorites();
  }catch(e){
    if(controller.signal.aborted||optionRequests.get(root)!==controller||!root.isConnected)return;
    // Roll back the controls to the visible, server-rendered variant on a network error.
    root.querySelectorAll('[data-option-value]').forEach(radio=>radio.checked=radio.defaultChecked);
    buttons.forEach((button,index)=>button.disabled=root._optionButtonStates[index]);
    if(error)error.textContent=e.message;
  }finally{
    if(optionRequests.get(root)===controller){root.removeAttribute('aria-busy');root.querySelectorAll('.shopify-payment-button').forEach(el=>el.inert=false);delete root._optionButtonStates;}
  }
}
function selectGalleryThumb(thumb){
  const gallery=thumb.closest('[data-gallery]')||thumb.closest('[data-product-root]');
  const main=gallery?.querySelector('.gallery-main');if(!main)return;
  main.removeAttribute('srcset');main.removeAttribute('sizes');main.src=thumb.dataset.gallerySrc;main.alt=thumb.dataset.galleryAlt||'';
  gallery.querySelectorAll('[data-gallery-src]').forEach(button=>button.setAttribute('aria-current',String(button===thumb)));
}

function wholesaleSummary(){let count=0,total=0;document.querySelectorAll('[data-wholesale-variant]').forEach(i=>{if(i.disabled||!i.checkValidity())return;const q=Number(i.value)||0;count+=q;total+=q*Number(i.dataset.wholesalePrice);});const c=document.querySelector('[data-wholesale-count]'),t=document.querySelector('[data-wholesale-total]'),b=document.querySelector('[data-wholesale-add]');if(c)c.textContent=count;if(t)t.textContent=money(total);if(b)b.disabled=count===0;}
async function wholesaleAdd(button){if(cartBusy)return;const fields=[...document.querySelectorAll('[data-wholesale-variant]')];if(fields.some(i=>!i.disabled&&!i.reportValidity()))return;const items=fields.filter(i=>!i.disabled&&Number(i.value)>0).map(i=>({id:Number(i.dataset.wholesaleVariant),quantity:Number(i.value)}));if(!items.length)return;cartBusy=true;button.disabled=true;const error=document.querySelector('[data-wholesale-error]');error.textContent='';try{await jsonFetch(cfg.root+'cart/add.js',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({items})});fields.forEach(i=>i.value='0');wholesaleSummary();await openCart();}catch(e){error.textContent=e.message;}finally{cartBusy=false;wholesaleSummary();}}
document.addEventListener('click',e=>{const target=e.target,tab=target.closest('[data-collection-tab]');if(tab){const section=tab.closest('section');section.querySelectorAll('[data-collection-tab]').forEach(b=>b.setAttribute('aria-selected',String(b===tab)));section.querySelectorAll('[role=tabpanel]').forEach(panel=>panel.hidden=panel.id!==tab.getAttribute('aria-controls'));}const open=target.closest('[data-open-cart]');if(open&&drawer){e.preventDefault();openCart();}if(target.closest('[data-close-cart]'))drawer.close();if(target.closest('[data-close-quick]'))quick.close();if(target.closest('[data-close-zoom]'))zoom.close();const menu=target.closest('[data-menu-toggle]');if(menu){const expanded=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(expanded));document.getElementById('MainMenu').classList.toggle('open',expanded);}const change=target.closest('[data-cart-key]');if(change)changeCart(change);const favorite=target.closest('[data-favorite]');if(favorite)toggleFavorite(favorite);const buy=target.closest('[data-quick-buy]');if(buy)quickBuy(buy);const thumb=target.closest('[data-gallery-src]');if(thumb)selectGalleryThumb(thumb);const galleryStep=target.closest('[data-gallery-step]');if(galleryStep){const thumbs=[...galleryStep.closest('[data-gallery]').querySelectorAll('[data-gallery-src]')];if(thumbs.length){const index=Math.max(0,thumbs.findIndex(t=>t.getAttribute('aria-current')==='true'));selectGalleryThumb(thumbs[(index+Number(galleryStep.dataset.galleryStep)+thumbs.length)%thumbs.length]);}}const zb=target.closest('[data-zoom]');if(zb){const main=zb.closest('[data-product-root]').querySelector('.gallery-main');if(main){zoom.querySelector('img').src=main.currentSrc||main.src;zoom.querySelector('img').alt=main.alt;zoom.showModal();}}const step=target.closest('[data-qty-step]');if(step){const i=step.closest('.quantity').querySelector('input');if(Number(step.dataset.qtyStep)>0)i.stepUp();else if(Number(i.value)>Number(i.min||1))i.stepDown();i.dispatchEvent(new Event('change',{bubbles:true}));}const sticky=target.closest('[data-sticky-add]');if(sticky)sticky.closest('[data-product-root]').querySelector('[data-product-form]').requestSubmit();const wholesale=target.closest('[data-wholesale-add]');if(wholesale)wholesaleAdd(wholesale);});
document.addEventListener('click',e=>{
  const open=e.target.closest('[data-open-size]');
  if(open){const dialog=document.getElementById(open.getAttribute('aria-controls'));if(dialog){dialog._opener=open;dialog.showModal();}}
  const close=e.target.closest('[data-close-size]');if(close)close.closest('[data-size-chart]')?.close();
  const dialog=e.target;if(dialog.matches?.('[data-size-chart]')){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}
});
document.addEventListener('close',e=>{if(e.target.matches?.('[data-size-chart]'))e.target._opener?.focus({preventScroll:true});},true);
document.addEventListener('shopify:block:select',e=>{
  if(!window.Shopify?.designMode)return;
  const block=e.target.closest('[data-product-block]')||e.target.querySelector?.('[data-product-block]');
  if(!block)return;
  const details=block.querySelector('.product-accordion');if(details)details.open=true;
  block.scrollIntoView?.({block:'center',behavior:'auto'});
});
document.addEventListener('change',e=>{if(e.target.matches('[data-option-value]'))updateOptions(e.target);});document.addEventListener('input',e=>{if(e.target.matches('[data-wholesale-variant]'))wholesaleSummary();});
document.addEventListener('submit',async e=>{const form=e.target;if(!form.matches('[data-product-form]'))return;e.preventDefault();if(cartBusy)return;if(form.closest('[aria-busy=true]')||form.querySelector('[data-add-button]').disabled)return;const id=form.querySelector('[name=id]')?.value;if(!id){form.querySelector('.form-error').textContent=i18n.variant_unavailable;return;}cartBusy=true;const button=form.querySelector('[data-add-button]'),error=form.querySelector('.form-error'),label=button.textContent;button.disabled=true;button.textContent=i18n.adding;error.textContent='';try{await jsonFetch(cfg.root+'cart/add.js',{method:'POST',body:new FormData(form),headers:{Accept:'application/json'}});if(quick.open)quick.close();await openCart();}catch(err){error.textContent=err.message;}finally{cartBusy=false;button.disabled=false;button.textContent=label;}});
for(const dialog of [drawer,quick,zoom])dialog?.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();});
async function initFavorites(){const grid=document.querySelector('[data-favorites-grid]');if(!grid)return;grid.replaceChildren();const list=favorites();if(!list.length){grid.append(text('p',i18n.favorites_empty));return;}for(const handle of list){try{const url=cfg.root+'products/'+encodeURIComponent(handle),r=await fetch(url+'.js');if(!r.ok)continue;const p=await r.json(),card=text('article','');card.className='product-card';const link=text('a','');link.href=url;link.className='product-image';if(p.featured_image){const img=document.createElement('img');img.src=p.featured_image;img.alt=p.title;link.append(img);}const info=text('div','');info.className='product-card-info';info.append(text('p',p.title),text('p',money(p.price)));const button=text('button',i18n.choose_size);button.className='card-buy';button.dataset.quickBuy=url;card.append(link,info,button);grid.append(card);}catch{}}if(!grid.childElementCount)grid.append(text('p',i18n.favorites_unavailable));}
async function recommendations(){
  for(const section of document.querySelectorAll('[data-recommendations]')){
    if(section._lookLoading||section._lookLoaded)continue;
    section._lookLoading=true;
    const grid=section.querySelector('.product-grid'),note=section.querySelector('[data-look-editor-note]');
    try{
      const response=await fetch(section.dataset.url);if(!response.ok)throw Error('Recommendations unavailable');
      const content=parseHTML(await response.text()).querySelector('[data-recommendations] .product-grid');
      if(!section.isConnected)continue;
      if(content?.childElementCount)grid.replaceChildren(...content.children);
      section._lookLoaded=true;
    }catch{/* Keep the merchant's fallback collection visible after a failed request. */}
    finally{
      section._lookLoading=false;
      if(section.isConnected){const hasProducts=!!grid?.childElementCount;section.hidden=!hasProducts&&!window.Shopify?.designMode;if(note)note.hidden=hasProducts;}
    }
  }
  syncFavorites();
}
function prefixQuickIds(root){root.querySelectorAll('[data-option-value][name]').forEach(el=>el.name='Quick-'+el.name);const ids=new Map();root.querySelectorAll('[id]').forEach(el=>{const next='Quick-'+el.id;ids.set(el.id,next);el.id=next;});root.querySelectorAll('[for],[form],[aria-controls],[aria-labelledby],[aria-describedby]').forEach(el=>{for(const name of ['for','form','aria-controls','aria-labelledby','aria-describedby'])if(el.hasAttribute(name))el.setAttribute(name,el.getAttribute(name).split(' ').map(id=>ids.get(id)||id).join(' '));});}
function initSticky(scope=document){if(typeof IntersectionObserver==='undefined')return;scope.querySelectorAll('[data-product-form]').forEach(form=>{const root=form.closest('[data-product-root]'),bar=root?.querySelector('.sticky-buy');if(!bar||root.closest('#QuickBuy'))return;root._stickyObserver?.disconnect();const observer=new IntersectionObserver(entries=>{bar.classList.toggle('is-visible',!entries[0].isIntersecting);},{threshold:0});root._stickyObserver=observer;observer.observe(form.querySelector('[data-add-button]'));});}
function init(){initSticky();syncFavorites();wholesaleSummary();recommendations();const filters=document.querySelector('.catalog-layout .filters');if(filters&&matchMedia('(max-width:650px)').matches)filters.open=false;}init();initFavorites();document.addEventListener('shopify:section:load',init);
})();
